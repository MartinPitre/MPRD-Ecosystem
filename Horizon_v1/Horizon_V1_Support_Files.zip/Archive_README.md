# Archive

This folder preserves superseded, historical, or retired validation documents.

Purpose:
- Maintain project history
- Preserve audit trails
- Support reproducibility
