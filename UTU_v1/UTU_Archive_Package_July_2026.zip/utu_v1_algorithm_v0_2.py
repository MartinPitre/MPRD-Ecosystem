"""
UTU_v1 — Uncertainty Targeting Unit Algorithm v0.2
Author: Martin Pitre
Purpose: Scout observations, generate research questions, score investigation value,
and recommend the next action in the UBv1 recursive research architecture.

Architecture position:
UTU -> UTA -> UBv1 -> Implementation -> UTU

v0.2 improvements:
1. Preserves score rationale notes for auditability.
2. Adds confidence scoring for the evaluation itself.
3. Applies weighted priority scoring, with importance weighted more heavily.
4. Adds audit metadata, including created/reviewed timestamps and reviewer.
"""

from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from typing import Dict, Optional


SCORE_LABELS = {
    0: "Low",
    1: "Moderate",
    2: "High",
}


CONFIDENCE_LABELS = {
    0: "Low Confidence",
    1: "Moderate Confidence",
    2: "High Confidence",
}


@dataclass
class UTUInput:
    observation: str
    pattern_or_anomaly: str
    candidate_question: str
    novelty: int
    uncertainty_level: int
    importance: int
    testability: int
    evidence_availability: int
    confidence: int = 1
    score_notes: Dict[str, str] = field(default_factory=dict)
    reviewer: str = "Unspecified"
    date_created: Optional[str] = None
    date_reviewed: Optional[str] = None


@dataclass
class UTUResult:
    observation: str
    pattern_or_anomaly: str
    candidate_question: str
    scores: Dict[str, int]
    score_notes: Dict[str, str]
    weights: Dict[str, int]
    raw_priority_score: int
    weighted_priority_score: int
    max_weighted_score: int
    confidence: int
    confidence_label: str
    priority_band: str
    recommended_action: str
    destination: str
    audit: Dict[str, str]


class UTUv1:
    """Operational UTU scout algorithm with audit-ready v0.2 improvements."""

    SCORE_FIELDS = [
        "novelty",
        "uncertainty_level",
        "importance",
        "testability",
        "evidence_availability",
    ]

    # Importance is weighted more heavily because high-impact uncertainty
    # should receive stronger prioritization in the research workflow.
    WEIGHTS = {
        "novelty": 1,
        "uncertainty_level": 1,
        "importance": 2,
        "testability": 1,
        "evidence_availability": 1,
    }

    def validate_score(self, name: str, value: int) -> None:
        if value not in (0, 1, 2):
            raise ValueError(f"{name} must be 0, 1, or 2. Received: {value}")

    def current_timestamp(self) -> str:
        return datetime.now(timezone.utc).isoformat()

    def max_weighted_score(self) -> int:
        return sum(2 * weight for weight in self.WEIGHTS.values())

    def classify_priority(self, weighted_score: int) -> str:
        """Classify weighted score on a 0-12 scale."""
        if weighted_score <= 4:
            return "Archive Only"
        if weighted_score <= 7:
            return "Monitor"
        if weighted_score <= 10:
            return "Investigate"
        return "High-Priority Target"

    def recommend_action(self, band: str) -> str:
        actions = {
            "Archive Only": "Record briefly in UBv1 if useful, but do not open an active investigation.",
            "Monitor": "Track the observation and wait for more evidence before escalating.",
            "Investigate": "Create an investigation target and prepare evidence collection.",
            "High-Priority Target": "Forward immediately to UTA for uncertainty transformation analysis and to UBv1 for preservation.",
        }
        return actions[band]

    def destination(self, band: str) -> str:
        destinations = {
            "Archive Only": "UBv1 note only",
            "Monitor": "UBv1 watchlist",
            "Investigate": "UTA + UBv1",
            "High-Priority Target": "UTA + UBv1 + Implementation planning",
        }
        return destinations[band]

    def evaluate(self, entry: UTUInput) -> UTUResult:
        raw = asdict(entry)
        scores: Dict[str, int] = {}

        for field_name in self.SCORE_FIELDS:
            value = raw[field_name]
            self.validate_score(field_name, value)
            scores[field_name] = value

        self.validate_score("confidence", entry.confidence)

        raw_priority_score = sum(scores.values())
        weighted_priority_score = sum(
            scores[field_name] * self.WEIGHTS[field_name]
            for field_name in self.SCORE_FIELDS
        )
        priority_band = self.classify_priority(weighted_priority_score)

        audit = {
            "reviewer": entry.reviewer,
            "date_created": entry.date_created or self.current_timestamp(),
            "date_reviewed": entry.date_reviewed or self.current_timestamp(),
            "algorithm_version": "UTU_v1 v0.2",
        }

        return UTUResult(
            observation=entry.observation,
            pattern_or_anomaly=entry.pattern_or_anomaly,
            candidate_question=entry.candidate_question,
            scores=scores,
            score_notes=entry.score_notes,
            weights=self.WEIGHTS,
            raw_priority_score=raw_priority_score,
            weighted_priority_score=weighted_priority_score,
            max_weighted_score=self.max_weighted_score(),
            confidence=entry.confidence,
            confidence_label=CONFIDENCE_LABELS[entry.confidence],
            priority_band=priority_band,
            recommended_action=self.recommend_action(priority_band),
            destination=self.destination(priority_band),
            audit=audit,
        )


def print_result(result: UTUResult) -> None:
    print("UTU_v1 Evaluation Result")
    print("------------------------")
    print(f"Observation: {result.observation}")
    print(f"Pattern / Anomaly: {result.pattern_or_anomaly}")
    print(f"Candidate Question: {result.candidate_question}")

    print("\nScores:")
    for name, value in result.scores.items():
        readable_name = name.replace("_", " ").title()
        weight = result.weights[name]
        note = result.score_notes.get(name, "No rationale note provided.")
        print(f"- {readable_name}: {value} ({SCORE_LABELS[value]}), Weight: {weight}")
        print(f"  Note: {note}")

    print(f"\nRaw Priority Score: {result.raw_priority_score}/10")
    print(
        f"Weighted Priority Score: "
        f"{result.weighted_priority_score}/{result.max_weighted_score}"
    )
    print(f"Confidence: {result.confidence} ({result.confidence_label})")
    print(f"Priority Band: {result.priority_band}")
    print(f"Recommended Action: {result.recommended_action}")
    print(f"Destination: {result.destination}")

    print("\nAudit:")
    for key, value in result.audit.items():
        readable_key = key.replace("_", " ").title()
        print(f"- {readable_key}: {value}")


def demo() -> None:
    utu = UTUv1()

    horizon_example = UTUInput(
        observation="Horizon results demonstrate stable recovery across multiple noise levels.",
        pattern_or_anomaly="Detection appears robust under repeated noisy trials.",
        candidate_question="Is recovery stability maintained under more extreme or varied conditions?",
        novelty=2,
        uncertainty_level=2,
        importance=2,
        testability=2,
        evidence_availability=2,
        confidence=2,
        score_notes={
            "novelty": "The result may reveal a new stability boundary for the system.",
            "uncertainty_level": "Extreme-condition behavior remains unknown.",
            "importance": "Stability limits are important for deciding whether the method can generalize.",
            "testability": "The question can be tested by increasing noise and varying trial conditions.",
            "evidence_availability": "Existing horizon outputs provide a starting evidence base.",
        },
        reviewer="Martin Pitre",
    )

    result = utu.evaluate(horizon_example)
    print_result(result)


if __name__ == "__main__":
    demo()
