"""
UTU_v1 — Uncertainty Targeting Unit Algorithm v0.1
Author: Martin Pitre
Purpose: Scout observations, generate research questions, score investigation value,
and recommend the next action in the UBv1 recursive research architecture.

Architecture position:
UTU -> UTA -> UBv1 -> Implementation -> UTU
"""

from dataclasses import dataclass, asdict
from typing import Dict, List


SCORE_LABELS = {
    0: "Low",
    1: "Moderate",
    2: "High",
}


@dataclass
class UTUInput:
    observation: str
    pattern_or_anomaly: str
    candidate_question: str
    novelty: int
    uncertainty_level: int
    importance: int
    testability: int
    evidence_availability: int


@dataclass
class UTUResult:
    observation: str
    pattern_or_anomaly: str
    candidate_question: str
    scores: Dict[str, int]
    priority_score: int
    priority_band: str
    recommended_action: str
    destination: str


class UTUv1:
    """First operational UTU scout algorithm."""

    SCORE_FIELDS = [
        "novelty",
        "uncertainty_level",
        "importance",
        "testability",
        "evidence_availability",
    ]

    def validate_score(self, name: str, value: int) -> None:
        if value not in (0, 1, 2):
            raise ValueError(f"{name} must be 0, 1, or 2. Received: {value}")

    def classify_priority(self, score: int) -> str:
        if score <= 3:
            return "Archive Only"
        if score <= 6:
            return "Monitor"
        if score <= 8:
            return "Investigate"
        return "High-Priority Target"

    def recommend_action(self, band: str) -> str:
        actions = {
            "Archive Only": "Record briefly in UBv1 if useful, but do not open an active investigation.",
            "Monitor": "Track the observation and wait for more evidence before escalating.",
            "Investigate": "Create an investigation target and prepare evidence collection.",
            "High-Priority Target": "Forward immediately to UTA for uncertainty transformation analysis and to UBv1 for preservation.",
        }
        return actions[band]

    def destination(self, band: str) -> str:
        destinations = {
            "Archive Only": "UBv1 note only",
            "Monitor": "UBv1 watchlist",
            "Investigate": "UTA + UBv1",
            "High-Priority Target": "UTA + UBv1 + Implementation planning",
        }
        return destinations[band]

    def evaluate(self, entry: UTUInput) -> UTUResult:
        raw = asdict(entry)
        scores = {}

        for field in self.SCORE_FIELDS:
            value = raw[field]
            self.validate_score(field, value)
            scores[field] = value

        priority_score = sum(scores.values())
        priority_band = self.classify_priority(priority_score)

        return UTUResult(
            observation=entry.observation,
            pattern_or_anomaly=entry.pattern_or_anomaly,
            candidate_question=entry.candidate_question,
            scores=scores,
            priority_score=priority_score,
            priority_band=priority_band,
            recommended_action=self.recommend_action(priority_band),
            destination=self.destination(priority_band),
        )


def print_result(result: UTUResult) -> None:
    print("UTU_v1 Evaluation Result")
    print("------------------------")
    print(f"Observation: {result.observation}")
    print(f"Pattern / Anomaly: {result.pattern_or_anomaly}")
    print(f"Candidate Question: {result.candidate_question}")
    print("\nScores:")
    for name, value in result.scores.items():
        readable_name = name.replace("_", " ").title()
        print(f"- {readable_name}: {value} ({SCORE_LABELS[value]})")
    print(f"\nPriority Score: {result.priority_score}/10")
    print(f"Priority Band: {result.priority_band}")
    print(f"Recommended Action: {result.recommended_action}")
    print(f"Destination: {result.destination}")


def demo() -> None:
    utu = UTUv1()

    horizon_example = UTUInput(
        observation="Horizon results demonstrate stable recovery across multiple noise levels.",
        pattern_or_anomaly="Detection appears robust under repeated noisy trials.",
        candidate_question="Is recovery stability maintained under more extreme or varied conditions?",
        novelty=2,
        uncertainty_level=2,
        importance=2,
        testability=2,
        evidence_availability=2,
    )

    result = utu.evaluate(horizon_example)
    print_result(result)


if __name__ == "__main__":
    demo()
