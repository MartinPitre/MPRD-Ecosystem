"""
AIRA_V1.py
Algorithmic Interaction Relationship Assessment
Version: v1.0
Date: July 6, 2026
Author: Martin Pitre

AIRA_V1 is a first-pass research algorithm for testing whether an observed
concept, event, or interaction belongs closer to MPRD, UBv1, UTA, SUANR,
publication-ecosystem studies, or should remain open/unplaced.

Core principle:
Do not place a concept inside a framework simply because it resembles the
framework. Place it only when evidence supports the relationship.
Default status when evidence is incomplete: Open/Unplaced.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


CRITERIA = [
    "origin_match",
    "component_match",
    "operational_fit",
    "evidence_strength",
    "placement_risk",
]

CRITERION_DESCRIPTIONS = {
    "origin_match": "Did the concept arise from the framework itself, or independently from direct observation?",
    "component_match": "Does it share structure with known components such as distinction, recursion, persistence, uncertainty transformation, evidence accumulation, or predictive uncertainty?",
    "operational_fit": "Can the concept be tested using existing framework tools or variables?",
    "evidence_strength": "Are there repeated examples, saved notes, data, code, or external observations supporting the link?",
    "placement_risk": "Would assigning it too early distort either the concept or the framework?",
}

OUTPUT_CATEGORIES = {
    "MPRD": "MPRD-Aligned",
    "UBv1": "UBv1-Aligned",
    "UTA": "UTA-Aligned",
    "SUANR": "SUANR-Aligned",
    "Publication Ecosystem": "Publication-Ecosystem Aligned",
}

CATEGORY_MEANINGS = {
    "MPRD-Aligned": "Strong match to relational distinction, persistence, recursive development, self-modeling, or truth integration.",
    "UBv1-Aligned": "Strong match to uncertainty logging, evidence accumulation, open questions, or research diary evolution.",
    "UTA-Aligned": "Strong match to uncertainty reduction, creation, splitting, merging, or event-type transformation.",
    "SUANR-Aligned": "Strong match to predictive uncertainty, regression, uncertainty estimates, error-risk relationship, or uncertainty-aware modeling.",
    "Publication-Ecosystem Aligned": "Strong match to how ideas, posts, files, algorithms, and public research artifacts interact after publication.",
    "Open/Unplaced": "Evidence is insufficient, mixed, or premature. Preserve and retest later.",
}


@dataclass
class CandidateAssessment:
    """Assessment result for one candidate framework."""

    candidate: str
    scores: Dict[str, int]
    evidence_notes: List[str] = field(default_factory=list)
    risk_note: str = ""

    def __post_init__(self) -> None:
        missing = [criterion for criterion in CRITERIA if criterion not in self.scores]
        if missing:
            raise ValueError(f"Missing score(s) for: {', '.join(missing)}")

        for criterion, score in self.scores.items():
            if criterion not in CRITERIA:
                raise ValueError(f"Unknown criterion: {criterion}")
            if not isinstance(score, int) or score < 0 or score > 2:
                raise ValueError(f"Score for {criterion} must be an integer from 0 to 2.")

    @property
    def total_score(self) -> int:
        return sum(self.scores.values())

    @property
    def placement_risk_score(self) -> int:
        return self.scores["placement_risk"]

    @property
    def interpretation(self) -> str:
        score = self.total_score
        if score <= 3:
            return "Weak relationship. Keep Open/Unplaced."
        if score <= 6:
            return "Possible relationship. Preserve and collect more evidence."
        if score <= 8:
            return "Probable relationship. Provisional alignment allowed."
        return "Strong relationship. Candidate for integration or formal expansion."

    @property
    def output_category(self) -> str:
        return OUTPUT_CATEGORIES.get(self.candidate, f"{self.candidate}-Aligned")


def classify_candidate(assessment: CandidateAssessment) -> str:
    """
    Classify one candidate framework conservatively.

    Placement risk is treated as a brake: a high placement-risk score can keep
    the result open even when other signals look promising.
    """
    total = assessment.total_score
    risk = assessment.placement_risk_score

    if total <= 3:
        return "Open/Unplaced"
    if total <= 6:
        return "Open/Unplaced"
    if risk == 2 and total < 9:
        return "Open/Unplaced"
    if total >= 7:
        return assessment.output_category
    return "Open/Unplaced"


def select_strongest_supported_category(
    assessments: List[CandidateAssessment],
) -> Tuple[str, Optional[CandidateAssessment]]:
    """
    Select the strongest supported category across candidates.

    If no candidate reaches conservative evidence thresholds, return
    Open/Unplaced. Ties are kept open to avoid forcing premature placement.
    """
    if not assessments:
        return "Open/Unplaced", None

    ranked = sorted(assessments, key=lambda item: item.total_score, reverse=True)
    top = ranked[0]
    tied_top = [item for item in ranked if item.total_score == top.total_score]

    if len(tied_top) > 1:
        return "Open/Unplaced", None

    classification = classify_candidate(top)
    if classification == "Open/Unplaced":
        return "Open/Unplaced", top

    return classification, top


def run_aira_v1(
    observed_concept: str,
    origin_context: str,
    assessments: List[CandidateAssessment],
    general_evidence_notes: Optional[List[str]] = None,
) -> Dict[str, object]:
    """Run the AIRA_V1 procedure and return a structured research note."""
    classification, strongest = select_strongest_supported_category(assessments)

    return {
        "algorithm": "AIRA_V1",
        "version": "v1.0",
        "observed_concept": observed_concept,
        "origin_context": origin_context,
        "general_evidence_notes": general_evidence_notes or [],
        "recommended_classification": classification,
        "classification_meaning": CATEGORY_MEANINGS.get(classification, "Provisional aligned category."),
        "strongest_candidate": strongest.candidate if strongest else None,
        "candidate_results": [
            {
                "candidate": assessment.candidate,
                "scores": assessment.scores,
                "total_score": assessment.total_score,
                "interpretation": assessment.interpretation,
                "candidate_classification": classify_candidate(assessment),
                "evidence_notes": assessment.evidence_notes,
                "risk_note": assessment.risk_note,
            }
            for assessment in assessments
        ],
        "freeze_statement": (
            "AIRA_V1 is frozen as a first-pass assessment algorithm. Future versions may add "
            "formal scoring sheets, code implementation, multi-observer scoring, and "
            "evidence-led threshold refinement."
        ),
    }


def format_report(result: Dict[str, object]) -> str:
    """Create a readable plain-text report from an AIRA_V1 result."""
    lines = [
        f"{result['algorithm']} {result['version']} Report",
        "=" * 40,
        f"Observed concept: {result['observed_concept']}",
        f"Origin context: {result['origin_context']}",
        f"Recommended classification: {result['recommended_classification']}",
        f"Meaning: {result['classification_meaning']}",
        f"Strongest candidate: {result['strongest_candidate'] or 'None / tie / insufficient evidence'}",
        "",
        "Candidate Results:",
    ]

    for candidate in result["candidate_results"]:
        lines.extend(
            [
                f"- {candidate['candidate']}: {candidate['total_score']}/10",
                f"  Interpretation: {candidate['interpretation']}",
                f"  Candidate classification: {candidate['candidate_classification']}",
            ]
        )
        if candidate["risk_note"]:
            lines.append(f"  Risk note: {candidate['risk_note']}")
        if candidate["evidence_notes"]:
            lines.append("  Evidence notes:")
            lines.extend(f"    - {note}" for note in candidate["evidence_notes"])

    lines.extend(["", f"Freeze statement: {result['freeze_statement']}"])
    return "\n".join(lines)


if __name__ == "__main__":
    # First test protocol: “When Algorithms Meet”
    # Initial state from the AIRA_V1 frozen document:
    # Relationship to MPRD remains under investigation. Preserve without forcing placement.
    first_test_assessments = [
        CandidateAssessment(
            candidate="MPRD",
            scores={
                "origin_match": 1,
                "component_match": 1,
                "operational_fit": 1,
                "evidence_strength": 1,
                "placement_risk": 2,
            },
            evidence_notes=[
                "Possible relation to relational distinction, recursion, persistence, and recursive development.",
                "Current evidence does not support full integration or separation.",
            ],
            risk_note="Forcing theory fit too early.",
        ),
        CandidateAssessment(
            candidate="UBv1",
            scores={
                "origin_match": 2,
                "component_match": 2,
                "operational_fit": 1,
                "evidence_strength": 1,
                "placement_risk": 0,
            },
            evidence_notes=[
                "Useful for open-question tracking, uncertainty-led preservation, and evidence-chain notes.",
            ],
            risk_note="May become only a storage category if not tested further.",
        ),
        CandidateAssessment(
            candidate="UTA",
            scores={
                "origin_match": 1,
                "component_match": 2,
                "operational_fit": 1,
                "evidence_strength": 1,
                "placement_risk": 1,
            },
            evidence_notes=[
                "Possible relation to uncertainty transformation caused by algorithm interaction.",
                "Needs measurable R/C/S/M pattern.",
            ],
            risk_note="Needs measurable R/C/S/M pattern.",
        ),
        CandidateAssessment(
            candidate="SUANR",
            scores={
                "origin_match": 0,
                "component_match": 1,
                "operational_fit": 0,
                "evidence_strength": 0,
                "placement_risk": 2,
            },
            evidence_notes=[
                "Connection remains unclear unless predictive uncertainty, code, or data evidence appears.",
            ],
            risk_note="May be too narrow unless code/data exists.",
        ),
        CandidateAssessment(
            candidate="Publication Ecosystem",
            scores={
                "origin_match": 1,
                "component_match": 2,
                "operational_fit": 1,
                "evidence_strength": 1,
                "placement_risk": 1,
            },
            evidence_notes=[
                "Possible relation to interactions between public artifacts, repositories, posts, readers, and algorithms.",
            ],
            risk_note="Needs observation logs.",
        ),
    ]

    result = run_aira_v1(
        observed_concept="When Algorithms Meet",
        origin_context=(
            "Relationship to MPRD remains under investigation. Current evidence supports neither "
            "full integration nor separation. Preserve without forcing theoretical placement."
        ),
        assessments=first_test_assessments,
        general_evidence_notes=[
            "Recommended first-test posture: Open/Unplaced with UBv1 preservation and possible MPRD/UTA/publication-ecosystem relevance."
        ],
    )

    print(format_report(result))
