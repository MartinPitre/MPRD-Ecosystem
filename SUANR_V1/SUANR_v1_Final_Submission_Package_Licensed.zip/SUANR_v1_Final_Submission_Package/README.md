# SUANR v1 Frozen Baseline Submission Package

Author: Martin Pitre

This package contains the frozen baseline release of SUANR v1: Stochastic Uncertainty-Aware Neural Regression.

## Contents

- `paper/` - main manuscript in DOCX and PDF formats.
- `appendix/` - theory appendix describing MPRD -> SUANR -> EDUM.
- `code/` - reference implementation and benchmark script.
- `benchmarks/` - benchmark summary table.
- `figures/` - benchmark visualization figures.
- `docs/` - reproducibility guide.

## Frozen baseline status

SUANR v1 is preserved as a fixed reference baseline for future comparisons against later versions such as SUANR v2. The goal of v1 is not to claim state-of-the-art performance, but to establish a reproducible uncertainty-aware regression baseline.

## Verified benchmark snapshot

Diabetes benchmark, 100-run evaluation:

| Model | MAE | RMSE |
|---|---:|---:|
| Linear Regression | 44.5463 | 54.8911 |
| Random Forest | 47.0133 | 57.9552 |
| SUANR v1 | 46.9497 | 57.9000 |

## Run benchmark

```bash
pip install numpy pandas scipy scikit-learn matplotlib
cd code
python benchmark_diabetes.py
```

## AI assistance disclosure

AI tools were used for drafting, coding assistance, editing, formatting, and organization. Scientific responsibility remains with the author.
