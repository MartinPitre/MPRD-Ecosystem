"""
Benchmark script for SUANR_v1 on the scikit-learn Diabetes regression dataset.
Produces repeated train/test metrics for Linear Regression, Random Forest, and SUANR_v1.
"""

import numpy as np
import pandas as pd
from sklearn.datasets import load_diabetes
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.model_selection import train_test_split

from suanr_v1 import SUANR_v1


def rmse(y_true, y_pred):
    return float(np.sqrt(mean_squared_error(y_true, y_pred)))


def run_benchmark(n_runs=100, test_size=0.2):
    X, y = load_diabetes(return_X_y=True)
    rows = []

    for seed in range(n_runs):
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=seed
        )

        models = {
            "LinearRegression": LinearRegression(),
            "RandomForest": RandomForestRegressor(n_estimators=100, random_state=seed),
            "SUANR_v1": SUANR_v1(random_state=seed),
        }

        for name, model in models.items():
            model.fit(X_train, y_train)
            preds = model.predict(X_test)
            rows.append(
                {
                    "run": seed,
                    "model": name,
                    "MAE": mean_absolute_error(y_test, preds),
                    "RMSE": rmse(y_test, preds),
                }
            )

    results = pd.DataFrame(rows)
    summary = results.groupby("model").agg(
        MAE_mean=("MAE", "mean"),
        MAE_std=("MAE", "std"),
        RMSE_mean=("RMSE", "mean"),
        RMSE_std=("RMSE", "std"),
    )
    return results, summary


if __name__ == "__main__":
    results, summary = run_benchmark(n_runs=100)
    results.to_csv("diabetes_benchmark_runs.csv", index=False)
    summary.to_csv("diabetes_benchmark_summary.csv")
    print(summary.round(4))
