"""
SUANR_v1 - Stochastic Uncertainty-Aware Neural Regression
Reference implementation for the SUANR v1 frozen baseline.

Author: Martin Pitre
Framework: MPRD -> SUANR -> EDUM
"""

import numpy as np
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from scipy.stats import entropy


class SUANR_v1:
    """
    Stochastic Uncertainty-Aware Neural Regression (SUANR v1).

    Outputs:
        - Prediction: mean prediction over stochastic forward samples.
        - Uncertainty: standard deviation over stochastic forward samples.
        - Entropy: histogram entropy of sampled predictions.
    """

    def __init__(
        self,
        hidden_layer_sizes=(64, 32),
        stochastic_noise=0.05,
        n_samples=50,
        random_state=42,
    ):
        self.hidden_layer_sizes = hidden_layer_sizes
        self.stochastic_noise = stochastic_noise
        self.n_samples = n_samples
        self.random_state = random_state
        self.scaler = StandardScaler()
        self.model = MLPRegressor(
            hidden_layer_sizes=hidden_layer_sizes,
            activation="relu",
            solver="adam",
            max_iter=1000,
            random_state=random_state,
        )

    def fit(self, X, y):
        """Fit the scaled neural regression model."""
        X_scaled = self.scaler.fit_transform(X)
        self.model.fit(X_scaled, y)
        return self

    def predict_with_uncertainty(self, X):
        """Return mean prediction, stochastic uncertainty, and entropy."""
        X_scaled = self.scaler.transform(X)
        predictions = []

        rng = np.random.default_rng(self.random_state)
        for _ in range(self.n_samples):
            noisy_X = X_scaled + rng.normal(0, self.stochastic_noise, X_scaled.shape)
            pred = self.model.predict(noisy_X)
            predictions.append(pred)

        predictions = np.array(predictions)
        mean_prediction = np.mean(predictions, axis=0)
        uncertainty = np.std(predictions, axis=0)

        entropy_values = []
        for i in range(predictions.shape[1]):
            sample_preds = predictions[:, i]
            hist, _ = np.histogram(sample_preds, bins=10, density=True)
            hist = hist + 1e-10
            entropy_values.append(entropy(hist))

        entropy_values = np.array(entropy_values)
        return mean_prediction, uncertainty, entropy_values

    def predict(self, X):
        """Compatibility helper: return only the mean prediction."""
        mean_prediction, _, _ = self.predict_with_uncertainty(X)
        return mean_prediction
