"""
UBv1 First Executable v1 Frozen
Author: Martin Pitre
Date: July 2, 2026

First executable UBv1 ledger prototype.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import List

VERSION = "UBv1_First_Executable_v1_Frozen"


@dataclass
class Evidence:
    description: str
    source: str
    strength: int
    notes: str = ""


@dataclass
class UBv1Entry:
    title: str
    category: str
    question: str
    status: str = "Draft"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    evidence: List[Evidence] = field(default_factory=list)
    uncertainty_old: int = 5
    reduction: int = 0
    creation: int = 0
    splitting: int = 0
    merging: int = 0

    def add_evidence(self, evidence: Evidence):
        self.evidence.append(evidence)

    def uncertainty_new(self):
        return (
            self.uncertainty_old
            - self.reduction
            + self.creation
            + self.splitting
            - self.merging
        )

    def recommendation(self):
        u_new = self.uncertainty_new()
        avg_strength = (
            sum(e.strength for e in self.evidence) / len(self.evidence)
            if self.evidence else 0
        )

        if avg_strength >= 8 and u_new <= 2:
            return "Freeze / Master Edition candidate"
        elif avg_strength >= 5:
            return "Keep testing / strengthen evidence"
        elif u_new > self.uncertainty_old:
            return "Send to UTU for scouting"
        else:
            return "Archive as draft"


entry = UBv1Entry(
    title="UTU v1 First Test",
    category="Algorithm Test",
    question="Can UTU scout observations?"
)

entry.add_evidence(
    Evidence(
        description="UTU v1 executed successfully",
        source="Google Colab",
        strength=8,
        notes="First successful run."
    )
)

entry.reduction = 3
entry.creation = 1
entry.splitting = 1
entry.merging = 0

print("Version:", VERSION)
print("Title:", entry.title)
print("Question:", entry.question)
print("New Uncertainty:", entry.uncertainty_new())
print("Recommendation:", entry.recommendation())
